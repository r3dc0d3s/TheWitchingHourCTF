# CBC Bit-Flipper

Can you flip your way to admin access?

Connect: `nc <server> <port>`

Points: 300
Category: Cryptography
Difficulty: Medium

Hint: CBC mode has interesting properties when you modify ciphertext...
